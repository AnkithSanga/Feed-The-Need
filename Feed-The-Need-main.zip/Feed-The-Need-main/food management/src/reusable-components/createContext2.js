import { createContext } from "react";

export const userContext2 = createContext(null);
