import { createContext } from "react";

export const userId = createContext(null);
